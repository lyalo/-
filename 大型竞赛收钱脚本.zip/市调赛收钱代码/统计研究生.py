import pandas as pd

# Load the Excel files
file_students_1 = '1028/graduate_students.xlsx'
file_students_2 = '1028/研究生.xlsx'

# Load the data
df_first = pd.read_excel(file_students_1)
df_new_second = pd.read_excel(file_students_2)

# Define the columns for comparison
name_column_first = "1、姓名"  # Name column in the first file
name_column_second_new = "学生姓名"  # Name column in the second file

# Find students in the second file but not in the first
students_in_second_not_in_first = df_new_second[~df_new_second[name_column_second_new].isin(df_first[name_column_first])]

# Find students in the first file but not in the second, including their submission time
students_in_first_not_in_second = df_first[~df_first[name_column_first].isin(df_new_second[name_column_second_new])][['1、姓名', '提交答卷时间']]

# Save the results to new Excel files
unpaid_file_path_new = '1028/研究生_报名但未交钱_new.xlsx'
not_counted_file_path_new = '1028/研究生_还未统计上_new.xlsx'

# Export students in the second file but not in the first
students_in_second_not_in_first.to_excel(unpaid_file_path_new, index=False)

# Export students in the first file but not in the second, with submission time
students_in_first_not_in_second.to_excel(not_counted_file_path_new, index=False)

# Provide file paths
print(f"Unpaid students saved at: {unpaid_file_path_new}")
print(f"Not counted students saved at: {not_counted_file_path_new}")
