import pandas as pd

# 读取Excel文件
file1_path = '本科生报名完成缴费.xlsx'
file2_path = '本科生（确定完毕）.xlsx'
file3_path = '研究生缴费完成.xlsx'
file4_path = '研究生（确定完毕）.xlsx'

file1_df = pd.read_excel(file1_path)
file2_df = pd.read_excel(file2_path)
file3_df = pd.read_excel(file3_path)
file4_df = pd.read_excel(file4_path)

# 本科生数据去重：从第一个表格中去掉在第二个表格中也有的学生
filtered_file1_df = file1_df[~file1_df['学生姓名'].isin(file2_df['学生姓名'])]

# 研究生数据去重：从第三个表格中去掉在第四个表格中也有的学生
filtered_file3_df = file3_df[~file3_df['学生姓名'].isin(file4_df['学生姓名'])]

# 导出结果（如果需要保存为Excel文件）
filtered_file1_df.to_excel("本科生去重后.xlsx", index=False)
filtered_file3_df.to_excel("研究生去重后.xlsx", index=False)
