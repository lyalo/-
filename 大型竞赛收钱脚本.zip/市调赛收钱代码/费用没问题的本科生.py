import pandas as pd

# Load the Excel files
file_students_1 = '1028/本科生.xlsx'
file_students_2 = '1028/报名但未交钱_new.xlsx'

# Load the data
df_first = pd.read_excel(file_students_1)
df_second = pd.read_excel(file_students_2)

# Define the columns for comparison
name_column_first = "学生姓名"  # Name column in the first file
name_column_second = "学生姓名"  # Name column in the second file

# Find the remaining students in the first file after removing those present in the second file
remaining_students = df_first[~df_first[name_column_first].isin(df_second[name_column_second])]

# Save the result to a new Excel file
remaining_students_file_path = '1028/剩余学生信息.xlsx'

# Export the remaining students' information
remaining_students.to_excel(remaining_students_file_path, index=False)

print(f"Remaining students information saved at: {remaining_students_file_path}")
