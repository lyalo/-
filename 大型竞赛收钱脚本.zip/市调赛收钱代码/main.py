import pandas as pd

# Load the Excel file
file_path = '1028/1027.xlsx'
df = pd.read_excel(file_path, sheet_name='Sheet1')

# Remove duplicates based on the "1、姓名" column, keeping the last occurrence
df_cleaned = df.drop_duplicates(subset="1、姓名", keep='last')

# Split the data into graduate and undergraduate based on the "5、年级" column
graduates = df_cleaned[df_cleaned["5、年级"].isin([5, 6, 7])]
undergraduates = df_cleaned[df_cleaned["5、年级"].isin([1, 2, 3, 4])]

# Calculate the total fees: graduates pay 20 per person, undergraduates pay 30 per person
graduate_fees = len(graduates) * 20
undergraduate_fees = len(undergraduates) * 30
total_fees = graduate_fees + undergraduate_fees
# Output the total fees
print(f"Graduate fees: {graduate_fees} RMB")
print(f"Undergraduate fees: {undergraduate_fees} RMB")
print(f"Total fees: {total_fees} RMB")

# Export the graduate and undergraduate tables to separate Excel files
graduates_file_path = '1028/graduate_students.xlsx'
undergraduates_file_path = '1028/undergraduate_students.xlsx'

graduates.to_excel(graduates_file_path, index=False)
undergraduates.to_excel(undergraduates_file_path, index=False)

# Output the total fees
print(f"Graduate fees: {graduate_fees} RMB")
print(f"Undergraduate fees: {undergraduate_fees} RMB")
print(f"Total fees: {total_fees} RMB")
