import pandas as pd

# Load the Excel file
file_remaining_students = '1028/研究生_剩余学生信息.xlsx'

# Load the data
df_remaining_students = pd.read_excel(file_remaining_students)

# Define the name column
name_column = "学生姓名"  # Ensure this is the correct column for student names

# Get the count of unique names
unique_name_count = df_remaining_students[name_column].nunique()

# Check for duplicate names
duplicate_names = df_remaining_students[df_remaining_students.duplicated(subset=[name_column], keep=False)]

# Check if there are any duplicate names
has_duplicates = not duplicate_names.empty

# Print results
print(f"Total unique names: {unique_name_count}")
if has_duplicates:
    print("There are duplicate names:")
    print(duplicate_names[[name_column]].drop_duplicates())
else:
    print("No duplicate names found.")
